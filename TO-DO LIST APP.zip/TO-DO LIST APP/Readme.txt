# To-Do List App 📝

A simple command-line To-Do List application built with Java.

## Features ✨
- ✅ Add tasks  
- ❌ Remove tasks  
- 📋 View all tasks  

## How to Run 🚀

### Locally
1. Clone the repository:
   ```sh
   git clone https://github.com/yourusername/todo-list-java.git
   cd todo-list-java
